# SMART-PRO — Relational database prototype v1.5

**Status: unvalidated PostgreSQL SQL prototype.** The migrations and tests have been written, but **not executed against PostgreSQL in the authoring environment**, which lacks the PostgreSQL server/client and Docker. Do **not** use for a real department without running tests, reviewing security/permissions, establishing the faculty's policies, and completing an operational review.

## What this contains

- `migrations/001_core.sql`: people, departments, academic cycles, policy versions, teams, projects, faculty and team history.
- `migrations/002_documents.sql`: private file metadata, immutable document versions, submission cases/attempts, submission-item ownership, approval decisions.
- `migrations/003_evaluation.sql`: centrally managed schemes and approved marking modes, exact rubric-scoped score records, eligibility snapshots, individual student results, published result history.
- `migrations/004_operations_and_guards.sql`: audit events, outbox, idempotency, notification deliveries, and defensive triggers enforcing rubric locks, score ceilings, roster locks, completeness and append-only academic evidence.
- `tests/001_seed.sql`: entirely fictional demo department, two students, one faculty guide, one academic admin, one submitted synopsis, one combined-mode evaluation, two published scores.
- `tests/002_constraints.sql`: rejection tests for cross-project attachments, incorrect score scopes, invalid totals, edited finalized marks, edited approved rubrics, altered locked rosters, edited releases/documents, duplicate idempotency keys, stale updates, cross-review roster use and incomplete scheme approval. Runs inside a transaction and rolls back its own test changes.
- `tests/003_smoke_queries.sql`: read-only inspection queries.
- `run-tests.sh`: migration/seed/test runner for an **empty test database**.
- `compose.yaml`: optional local-only PostgreSQL 16 container.

## Requirements and execution

PostgreSQL **15+** and a `psql` client. The SQL uses built-in `gen_random_uuid()` and `plpgsql` and does not need extra extensions. Running the script requires an **empty** database with permission to create tables/functions/triggers. The script is intentionally **not idempotent** and is **not** an upgrade path for existing databases.

Example using Docker Compose (if installed):

```bash
docker compose up -d
export DATABASE_URL='postgresql://smartpro:smartpro_local_only@127.0.0.1:54322/smartpro_dev'
export ALLOW_SMARTPRO_TEST_DB=YES
./run-tests.sh
```

For PowerShell on Windows, set `$env:DATABASE_URL` and `$env:ALLOW_SMARTPRO_TEST_DB = 'YES'`, then run the SQL files in the order shown above with a locally installed `psql` client; `run-tests.sh` requires Bash (Git Bash or WSL). **Never run this against a database containing real data.**

Expected synthetic results: Demo Student A **86/100** (52 team + 34 individual), Demo Student B **82/100** (52 team + 30 individual). The values demonstrate the data model, **not a verified faculty grading policy**.

## Approved design principles represented

- **One logical academic data model**, with separate module ownership; no backend framework has been chosen.
- Documents can have many immutable uploaded versions. A `submission_case` has many formal `submission_attempts` and each attempt references exact document versions.
- Department-managed evaluation schemes are versioned. Modes can be `TEAM`, `INDIVIDUAL`, or `COMBINED`, with approved criterion scopes.
- Team scores and student scores are separate; student marks refer to the review's frozen roster. Published individual results are immutable snapshots with source-assessment links.
- Database transactions, version-conditional updates, an outbox, and unique idempotency records are available to the *eventual application service*. These tables by themselves do not implement HTTP behavior or email delivery.

## Important limitations / future implementation

This is a **schema integrity prototype**, not a running SMART-PRO application. In particular:

1. **Authorization**: SQL constraints do not establish whether an actor is the currently assigned guide, an authorized evaluator or an HOD. The backend must check authenticated role, project relationship and current workflow state on every action; use restricted database service accounts. Authentication/SSO and role mapping are unresolved.
2. **Business state transitions**: Service-layer transactions must implement synopsis approval quorum/decisions, submission workflow changes, review mode selection, concurrency (`row_version` comparisons), result calculation/aggregation, publication authorization, and corresponding audit/outbox entries. The demo seed populates some related records directly; it is **not** an example of a secure production API.
3. **Result verification**: The prototype protects released score rows against modification but does **not** yet prove that every published result was calculated from finalized assessments or that all eligible students received a release. A publication service and corresponding transactional tests are required.
4. **Review membership**: The schema ensures a student's source membership belongs to the project team. A future service must additionally verify eligibility at the freeze date and apply approved team-transfer/absence rules. A locked roster cannot be edited through ordinary SQL; authorized correction needs a separate audited version/amendment workflow.
5. **File storage**: `file_assets` contains only metadata. A secure uploader must verify type, size, malware-scan status and actual object presence before accepting a version. File storage and database updates need recovery/reconciliation.
6. **Outbox**: Schema supports claim leases and retries; it does not implement a worker, dead-letter policy, exactly-once delivery, or provider acknowledgements.
7. **Academic decisions**: Faculty approval quorum, which role manages rubrics, individual-vs-team grading scope, evaluation aggregation formulas, and departmental retention are not confirmed. The sample calculation is illustrative.
8. **Tenant separation**: Composite keys defend many cross-project relationships, but a full department-scoped authorization and (if chosen) RLS strategy is not implemented.
9. **Operational readiness**: No credential protection, real-world data protection review, restore drill, performance test, production schema migration strategy or deployment owner is established.
10. **Schema size**: ~36 tables represent granular academic evidence and joins; they are not 36 deployable services. The final implementation may consolidate or refactor tables after executable verification and faculty rule confirmation.

## Acceptance thresholds before deployment

Use an actual PostgreSQL instance to execute all migrations and negative tests, then add transactional service tests for (a) exact role/project authorization, (b) concurrent approval conflicts, (c) membership changes and correction audits, (d) multi-evaluator aggregation, (e) final result publication completeness, (f) file-storage partial failure and recovery, and (g) background worker retry/deduplication. A green SQL test run alone is **not** production certification.
