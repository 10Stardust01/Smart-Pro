# SMART-PRO: Synopsis Workflow Contract Experiment v0.1

**Status:** runnable, locally tested **proof of concept**, **not** a production application and **not** a choice of Django, NestJS, or FastAPI for the final backend.

## What this demonstrates

An authorized student uploads a versioned synthetic synopsis (in a local, private test directory), formally submits it, an assigned faculty reviewer requests changes, the student uploads a new version, and the reviewer approves. Records of both attempts and decisions remain available. Also includes audit and outbox records, optimistic concurrency control (`expectedCaseVersion`), replay-safe idempotency keys, and cross-project access checks.

This is a thin, executable **business-contract harness**. It uses FastAPI so the API contract can be exercised automatically and uses SQLite because PostgreSQL is not available in the authoring environment. The separate PostgreSQL reference schema is included in the combined bundle for later server execution.

## Run locally

Python 3.11+ required. In a virtual environment:

```bash
pip install -r requirements.txt
python -m pytest -q tests/test_workflow.py
python app.py
```

The service binds to `127.0.0.1:8765` only. Browse `http://127.0.0.1:8765/docs` for the interactive API contract or use `openapi.json` (generated from this implementation).

Seeded local demo identifiers:

| Item | Value |
|---|---|
| Case | `case-1` |
| Project | `project-1` |
| Synopsis document | `synopsis-1` |
| Authorized student | `student-a` or `student-b` |
| Assigned faculty reviewer | `faculty-a` |
| Unauthorized reviewer | `faculty-other` |
| Outsider | `student-outsider` |

Demo identity uses the **insecure** `X-Demo-User` request header. It is deliberately unsuitable for department use. Do not expose this API on a network, deploy it, or use real student documents.

### Example manual sequence

1. `POST /api/v1/documents/synopsis-1/upload-sessions` with `X-Demo-User: student-a`.
2. `PUT /api/v1/upload-sessions/{uploadId}/content` with simple test bytes beginning `%PDF-` and the same header.
3. `POST /api/v1/upload-sessions/{uploadId}/complete` to get `documentVersionId`.
4. `POST /api/v1/submission-cases/case-1/attempts` with `X-Demo-User: student-a`, `Idempotency-Key: example-submit-1` and JSON:

```json
{"documentVersionIds":["<documentVersionId>"],"expectedCaseVersion":1}
```

5. `POST /api/v1/submission-attempts/{attemptId}/decisions` with `X-Demo-User: faculty-a`, `Idempotency-Key: example-decision-1` and JSON:

```json
{"decision":"REQUEST_CHANGES","comment":"Clarify the methodology","expectedCaseVersion":2}
```

6. Repeat the upload and submission using `expectedCaseVersion: 3` and a **new** idempotency key.
7. Approve the second attempt using `expectedCaseVersion: 4`, `decision: APPROVE` and a new key.
8. `GET /api/v1/submission-cases/case-1` displays both attempts and decisions.

For a repeatable test, run `python -m pytest -q` rather than manually managing identifiers.

## Verification

- **13/13 FastAPI/SQLite workflow tests pass** in the author's runtime (see `test-results.txt`). This validates the behavior of this harness only.
- Static lint on the bundled 36-table PostgreSQL prototype passes, including declared composite FK target checks.
- **The PostgreSQL migrations and PostgreSQL constraint tests have not run against PostgreSQL**. An actual PostgreSQL service was unavailable. They must run before the schema can be approved.

## Known limitations / work outstanding

- Authentication is simulated by a header, not SSO, sessions, or authorization middleware.
- Access control is a minimal hardcoded demonstration, not department-role and reviewer-quorum policy.
- File checking only tests size and a simple PDF prefix, **not** MIME trust, true format validation, malware scanning, storage hardening, or download permissions.
- File storage and SQLite are not one atomic transaction. This harness compensates in a limited failure path; it does not implement production-grade reconciliation or object storage.
- Outbox events are recorded but no worker, notification provider, lease, retry, or deduplication processor is running.
- API error details are demonstrative rather than the final RFC 9457 error model.
- It implements one-reviewer synopsis decisions. Faculty-dependent multiple-reviewer/quorum rules remain open.
- No project creation, evaluation grading or result release API is implemented; those are subsequent slices.
- SQLite behavior cannot validate PostgreSQL trigger syntax, row locks, composite constraints, or isolation behavior.
- OpenAPI captures actual HTTP shapes for this temporary harness but is **not yet the frozen production OpenAPI contract**.

## Architectural status

- Approved initial architectural direction: modular monolith (subject to future evidence).
- Backend selection: **NestJS versus Django remains undecided**.
- PostgreSQL remains a strong candidate and reference schema, not yet runtime-proven.
- Department-wide rubrics and all three assessment modes are approved design requirements, but this narrow PoC does not implement grading.
