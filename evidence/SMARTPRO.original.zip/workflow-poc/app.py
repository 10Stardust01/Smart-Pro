"""SMART-PRO framework-neutral contract experiment via FastAPI + SQLite.

NOT production: demo identity headers, SQLite instead of reference PostgreSQL,
local test-only file storage, no malware scan or HTTPS/SSO. The logic and tests
are intended to be ported to either Django or NestJS after the framework review.
"""
from __future__ import annotations
import hashlib
import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, Header, HTTPException, Request, Response
from pydantic import BaseModel, Field

ROOT = Path(os.getenv("SMARTPRO_DATA_DIR", Path(__file__).parent / '.demo-data'))
DB_FILE = ROOT / 'demo.sqlite3'
STORAGE = ROOT / 'files'
MAX_SIZE = 2 * 1024 * 1024  # DEMO ONLY

# Static fake accounts. This is NOT a production auth mechanism.
DEMO_USERS = {
    'student-a': 'STUDENT', 'student-b': 'STUDENT',
    'faculty-a': 'FACULTY', 'faculty-other': 'FACULTY',
    'student-outsider': 'STUDENT',
}

class SubmitAttempt(BaseModel):
    documentVersionIds: list[str] = Field(min_length=1, max_length=10)
    expectedCaseVersion: int = Field(ge=1)

class ReviewerDecision(BaseModel):
    decision: Literal['APPROVE', 'REQUEST_CHANGES']
    comment: str = Field(default='', max_length=4000)
    expectedCaseVersion: int = Field(ge=1)

class UploadStarted(BaseModel):
    uploadId: str
    maxBytes: int


def new_id(): return str(uuid.uuid4())

def connect():
    db = sqlite3.connect(DB_FILE, timeout=10, isolation_level=None, check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=10000')
    return db

@contextmanager
def transaction():
    db = connect()
    try:
        db.execute('BEGIN IMMEDIATE')
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def fail(status:int, code:str, detail:str):
    raise HTTPException(status_code=status, detail={'code':code, 'message': detail})

def principal(header:str | None):
    if header not in DEMO_USERS:
        fail(401, 'DEMO_AUTH_REQUIRED', 'Use a seeded X-Demo-User in the local test harness')
    return header

def require_project(db, project_id:str, actor:str, permission:str):
    if not db.execute('SELECT id FROM projects WHERE id=?', (project_id,)).fetchone():
        fail(404,'PROJECT_NOT_FOUND','Project not found')
    table = 'team_members' if permission=='student' else 'reviewer_assignments'
    if not db.execute(f'SELECT 1 FROM {table} WHERE project_id=? AND user_id=?', (project_id,actor)).fetchone():
        fail(403,'PROJECT_ACCESS_DENIED','User is not authorized for this project action')

def audit(db,actor,project,action,target):
    db.execute('INSERT INTO audit_events VALUES(?,?,?,?,?)',(new_id(),actor,project,action,target))

def event(db,event_type,case_id):
    db.execute('INSERT INTO outbox_events VALUES(?,?,?,?)',(new_id(),event_type,case_id,'PENDING'))

def idempotent(db,actor,operation,key,body:dict):
    if not key or len(key)>128: fail(400,'IDEMPOTENCY_REQUIRED','Provide an Idempotency-Key of up to 128 characters')
    digest=hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    old=db.execute('SELECT request_hash,response_json FROM idempotency WHERE actor=? AND operation=? AND idem_key=?',(actor,operation,key)).fetchone()
    if old:
        if old['request_hash'] != digest: fail(409,'IDEMPOTENCY_KEY_REUSED','Key already used for a different request')
        return (json.loads(old['response_json']), digest)
    return (None, digest)

def save_idempotency(db,actor,operation,key,digest,result):
    db.execute('INSERT INTO idempotency VALUES(?,?,?,?,?)',(actor,operation,key,digest,json.dumps(result)))

def init_demo(reset=False):
    ROOT.mkdir(parents=True,exist_ok=True); STORAGE.mkdir(parents=True,exist_ok=True)
    if reset and DB_FILE.exists(): DB_FILE.unlink()
    db=connect()
    db.executescript('''
    CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, title TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS team_members (project_id TEXT NOT NULL REFERENCES projects(id),user_id TEXT NOT NULL, PRIMARY KEY(project_id,user_id));
    CREATE TABLE IF NOT EXISTS reviewer_assignments (project_id TEXT NOT NULL REFERENCES projects(id),user_id TEXT NOT NULL, PRIMARY KEY(project_id,user_id));
    CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),doc_type TEXT NOT NULL,UNIQUE(id,project_id));
    CREATE TABLE IF NOT EXISTS upload_sessions(id TEXT PRIMARY KEY,document_id TEXT NOT NULL REFERENCES documents(id),user_id TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('PENDING','UPLOADED','COMPLETE')));
    CREATE TABLE IF NOT EXISTS file_assets(id TEXT PRIMARY KEY,path TEXT UNIQUE NOT NULL,sha256 TEXT NOT NULL,byte_size INTEGER NOT NULL CHECK(byte_size>0));
    CREATE TABLE IF NOT EXISTS document_versions(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,document_id TEXT NOT NULL,version_no INTEGER NOT NULL CHECK(version_no>0),file_asset_id TEXT NOT NULL UNIQUE REFERENCES file_assets(id),uploaded_by TEXT NOT NULL, FOREIGN KEY(document_id,project_id) REFERENCES documents(id,project_id), UNIQUE(document_id,version_no),UNIQUE(id,project_id));
    CREATE TABLE IF NOT EXISTS submission_cases(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),requirement_key TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('DRAFT','AWAITING_REVIEW','CHANGES_REQUESTED','APPROVED')),row_version INTEGER NOT NULL DEFAULT 1 CHECK(row_version>0),UNIQUE(id,project_id));
    CREATE TABLE IF NOT EXISTS submission_attempts(id TEXT PRIMARY KEY,case_id TEXT NOT NULL,project_id TEXT NOT NULL,attempt_no INTEGER NOT NULL,submitted_by TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('SUBMITTED','CHANGES_REQUESTED','APPROVED')),FOREIGN KEY(case_id,project_id) REFERENCES submission_cases(id,project_id), UNIQUE(case_id,attempt_no),UNIQUE(id,project_id));
    CREATE TABLE IF NOT EXISTS submission_items(attempt_id TEXT NOT NULL,project_id TEXT NOT NULL,document_version_id TEXT NOT NULL,PRIMARY KEY(attempt_id,document_version_id),FOREIGN KEY(attempt_id,project_id) REFERENCES submission_attempts(id,project_id),FOREIGN KEY(document_version_id,project_id) REFERENCES document_versions(id,project_id));
    CREATE TABLE IF NOT EXISTS approval_decisions(id TEXT PRIMARY KEY,attempt_id TEXT NOT NULL REFERENCES submission_attempts(id),reviewer_user_id TEXT NOT NULL,decision TEXT NOT NULL,comment TEXT NOT NULL,UNIQUE(attempt_id,reviewer_user_id));
    CREATE TABLE IF NOT EXISTS audit_events(id TEXT PRIMARY KEY,actor TEXT NOT NULL,project_id TEXT NOT NULL,action TEXT NOT NULL,target_id TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS outbox_events(id TEXT PRIMARY KEY,event_type TEXT NOT NULL,aggregate_id TEXT NOT NULL,status TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS idempotency(actor TEXT NOT NULL,operation TEXT NOT NULL,idem_key TEXT NOT NULL,request_hash TEXT NOT NULL,response_json TEXT NOT NULL,PRIMARY KEY(actor,operation,idem_key));
    CREATE TRIGGER IF NOT EXISTS immutable_document_versions_update BEFORE UPDATE ON document_versions BEGIN SELECT RAISE(ABORT,'immutable document version'); END;
    CREATE TRIGGER IF NOT EXISTS immutable_document_versions_delete BEFORE DELETE ON document_versions BEGIN SELECT RAISE(ABORT,'immutable document version'); END;
    CREATE TRIGGER IF NOT EXISTS immutable_submitted_items_update BEFORE UPDATE ON submission_items BEGIN SELECT RAISE(ABORT,'immutable submission item'); END;
    CREATE TRIGGER IF NOT EXISTS immutable_submitted_items_delete BEFORE DELETE ON submission_items BEGIN SELECT RAISE(ABORT,'immutable submission item'); END;
    CREATE TRIGGER IF NOT EXISTS immutable_approval_decisions_update BEFORE UPDATE ON approval_decisions BEGIN SELECT RAISE(ABORT,'immutable approval decision'); END;
    CREATE TRIGGER IF NOT EXISTS immutable_approval_decisions_delete BEFORE DELETE ON approval_decisions BEGIN SELECT RAISE(ABORT,'immutable approval decision'); END;
    ''')
    if not db.execute('SELECT 1 FROM projects LIMIT 1').fetchone():
        db.executemany('INSERT INTO projects VALUES(?,?)', [('project-1','Demo Library Project'),('project-2','Unrelated Project')])
        db.executemany('INSERT INTO team_members VALUES(?,?)',[('project-1','student-a'),('project-1','student-b'),('project-2','student-outsider')])
        db.execute('INSERT INTO reviewer_assignments VALUES (?,?)',('project-1','faculty-a'))
        db.executemany('INSERT INTO documents VALUES(?,?,?)',[('synopsis-1','project-1','SYNOPSIS'),('synopsis-2','project-2','SYNOPSIS')])
        db.execute('INSERT INTO submission_cases VALUES (?,?,?,?,?)',('case-1','project-1','SYNOPSIS:INITIAL','DRAFT',1))
    db.close()

app = FastAPI(title='SMART-PRO Synopsis Workflow — CONTRACT EXPERIMENT ONLY', version='0.1.0', description='Temporary FastAPI + SQLite implementation to validate API behavior; NOT a backend selection or production auth/storage.')

@app.post('/api/v1/documents/{document_id}/upload-sessions',status_code=201)
def start_upload(document_id:str,x_demo_user:str|None=Header(None)):
    actor=principal(x_demo_user)
    with transaction() as db:
        doc=db.execute('SELECT * FROM documents WHERE id=?',(document_id,)).fetchone()
        if not doc: fail(404,'DOCUMENT_NOT_FOUND','Unknown document')
        require_project(db,doc['project_id'],actor,'student')
        uid=new_id()
        db.execute('INSERT INTO upload_sessions VALUES(?,?,?,?)',(uid,document_id,actor,'PENDING'))
        return {'uploadId':uid,'maxBytes':MAX_SIZE,'status':'PENDING'}

@app.put('/api/v1/upload-sessions/{upload_id}/content')
async def put_upload(upload_id:str,request:Request,x_demo_user:str|None=Header(None)):
    actor=principal(x_demo_user)
    content = await request.body()
    if not content or len(content)>MAX_SIZE: fail(422,'BAD_FILE_SIZE','Empty or oversized test file')
    if not content.startswith(b'%PDF-'): fail(422,'BAD_FILE_FORMAT','Demo only accepts PDF signature')
    with transaction() as db:
        up=db.execute('SELECT * FROM upload_sessions WHERE id=?',(upload_id,)).fetchone()
        if not up: fail(404,'UPLOAD_NOT_FOUND','Unknown session')
        if up['user_id'] != actor: fail(403,'UPLOAD_OWNER_REQUIRED','Not your upload')
        if up['status'] != 'PENDING': fail(409,'UPLOAD_NOT_PENDING','Upload already used')
        path=STORAGE / f'{upload_id}.pending'
        path.write_bytes(content)
        db.execute('UPDATE upload_sessions SET status=? WHERE id=?',('UPLOADED',upload_id))
    return {'status':'UPLOADED','bytes':len(content)}

@app.post('/api/v1/upload-sessions/{upload_id}/complete',status_code=201)
def finish_upload(upload_id:str,x_demo_user:str|None=Header(None)):
    actor=principal(x_demo_user)
    with transaction() as db:
        up=db.execute('SELECT * FROM upload_sessions WHERE id=?',(upload_id,)).fetchone()
        if not up: fail(404,'UPLOAD_NOT_FOUND','Unknown session')
        if up['user_id']!=actor: fail(403,'UPLOAD_OWNER_REQUIRED','Not your upload')
        if up['status']!='UPLOADED': fail(409,'UPLOAD_NOT_READY','Upload has not completed')
        doc=db.execute('SELECT * FROM documents WHERE id=?',(up['document_id'],)).fetchone()
        require_project(db,doc['project_id'],actor,'student')
        src=STORAGE / f'{upload_id}.pending'
        if not src.is_file(): fail(422,'UPLOAD_MISSING','Uploaded bytes are missing')
        contents=src.read_bytes(); digest=hashlib.sha256(contents).hexdigest(); file_id=new_id(); version_id=new_id()
        version=db.execute('SELECT COALESCE(MAX(version_no),0)+1 n FROM document_versions WHERE document_id=?',(doc['id'],)).fetchone()['n']
        # The file store and DB aren't one atomic transaction. This demo uses a compensation step.
        # Production requires a pending/complete object protocol and orphan-file reconciliation.
        dest=STORAGE / f'{file_id}.pdf'
        src.replace(dest)
        try:
            db.execute('INSERT INTO file_assets VALUES (?,?,?,?)',(file_id,str(dest),digest,len(contents)))
            db.execute('INSERT INTO document_versions VALUES (?,?,?,?,?,?)',(version_id,doc['project_id'],doc['id'],version,file_id,actor))
            db.execute('UPDATE upload_sessions SET status=? WHERE id=?',('COMPLETE',upload_id))
            audit(db,actor,doc['project_id'],'DOCUMENT_VERSION_COMPLETED',version_id)
        except Exception:
            dest.replace(src)
            raise
    return {'documentVersionId':version_id,'versionNumber':version,'sha256':digest,'status':'READY'}

@app.post('/api/v1/submission-cases/{case_id}/attempts',status_code=201)
def submit_attempt(case_id:str,payload:SubmitAttempt,x_demo_user:str|None=Header(None),idempotency_key:str|None=Header(None)):
    actor=principal(x_demo_user)
    with transaction() as db:
        case=db.execute('SELECT * FROM submission_cases WHERE id=?',(case_id,)).fetchone()
        if not case: fail(404,'CASE_NOT_FOUND','Unknown case')
        require_project(db,case['project_id'],actor,'student')
        op=f'SUBMIT_ATTEMPT:{case_id}'
        old,digest=idempotent(db,actor,op,idempotency_key,payload.model_dump())
        if old: return old
        if case['row_version']!=payload.expectedCaseVersion: fail(409,'STALE_CASE_VERSION','Case changed; refresh it')
        if case['state'] not in ('DRAFT','CHANGES_REQUESTED'): fail(409,'CASE_NOT_SUBMITTABLE','Current case does not accept a new attempt')
        if len(set(payload.documentVersionIds))!=len(payload.documentVersionIds): fail(422,'DUPLICATE_VERSION','Version IDs must be unique')
        for vid in payload.documentVersionIds:
            doc=db.execute('SELECT dv.id,d.doc_type FROM document_versions dv JOIN documents d ON dv.document_id=d.id WHERE dv.id=? AND dv.project_id=?',(vid,case['project_id'])).fetchone()
            if not doc: fail(422,'INVALID_DOCUMENT_VERSION','Version not ready or belongs to another project')
            if doc['doc_type']!='SYNOPSIS': fail(422,'INVALID_DOCUMENT_TYPE','Synopsis case requires synopsis files')
        aid=new_id(); num=db.execute('SELECT COALESCE(MAX(attempt_no),0)+1 n FROM submission_attempts WHERE case_id=?',(case_id,)).fetchone()['n']
        db.execute('INSERT INTO submission_attempts VALUES (?,?,?,?,?,?)',(aid,case_id,case['project_id'],num,actor,'SUBMITTED'))
        for vid in payload.documentVersionIds:
            db.execute('INSERT INTO submission_items VALUES(?,?,?)',(aid,case['project_id'],vid))
        db.execute('UPDATE submission_cases SET state=?,row_version=row_version+1 WHERE id=?',('AWAITING_REVIEW',case_id))
        audit(db,actor,case['project_id'],'SUBMISSION_ATTEMPT_CREATED',aid); event(db,'SUBMISSION_RECEIVED',case_id)
        result={'caseId':case_id,'attemptId':aid,'attemptNumber':num,'caseVersion':case['row_version']+1,'status':'AWAITING_REVIEW'}
        save_idempotency(db,actor,op,idempotency_key,digest,result)
        return result

@app.post('/api/v1/submission-attempts/{attempt_id}/decisions',status_code=201)
def decide(attempt_id:str,payload:ReviewerDecision,x_demo_user:str|None=Header(None),idempotency_key:str|None=Header(None)):
    actor=principal(x_demo_user)
    with transaction() as db:
        attempt=db.execute('SELECT * FROM submission_attempts WHERE id=?',(attempt_id,)).fetchone()
        if not attempt: fail(404,'ATTEMPT_NOT_FOUND','Unknown attempt')
        require_project(db,attempt['project_id'],actor,'reviewer')
        op=f'REVIEW_DECISION:{attempt_id}'
        old,digest=idempotent(db,actor,op,idempotency_key,payload.model_dump())
        if old: return old
        case=db.execute('SELECT * FROM submission_cases WHERE id=?',(attempt['case_id'],)).fetchone()
        if case['row_version']!=payload.expectedCaseVersion: fail(409,'STALE_CASE_VERSION','Case changed; refresh it')
        if case['state']!='AWAITING_REVIEW' or attempt['state']!='SUBMITTED': fail(409,'INVALID_REVIEW_STATE','Attempt is not pending review')
        if not db.execute('SELECT 1 FROM submission_items WHERE attempt_id=?',(attempt_id,)).fetchone(): fail(422,'EMPTY_SUBMISSION','Cannot review empty attempt')
        decision_id=new_id(); state='APPROVED' if payload.decision=='APPROVE' else 'CHANGES_REQUESTED'
        db.execute('INSERT INTO approval_decisions VALUES(?,?,?,?,?)',(decision_id,attempt_id,actor,payload.decision,payload.comment))
        db.execute('UPDATE submission_attempts SET state=? WHERE id=?',(state,attempt_id))
        db.execute('UPDATE submission_cases SET state=?,row_version=row_version+1 WHERE id=?',(state,attempt['case_id']))
        audit(db,actor,attempt['project_id'],f'SUBMISSION_{state}',attempt_id)
        event(db,f'SUBMISSION_{state}',attempt['case_id'])
        result={'decisionId':decision_id,'caseId':attempt['case_id'],'attemptId':attempt_id,'status':state,'caseVersion':case['row_version']+1}
        save_idempotency(db,actor,op,idempotency_key,digest,result)
        return result

@app.get('/api/v1/submission-cases/{case_id}')
def read_case(case_id:str,x_demo_user:str|None=Header(None)):
    actor=principal(x_demo_user)
    db=connect()
    try:
        case=db.execute('SELECT * FROM submission_cases WHERE id=?',(case_id,)).fetchone()
        if not case: fail(404,'CASE_NOT_FOUND','Unknown case')
        if not (db.execute('SELECT 1 FROM team_members WHERE project_id=? AND user_id=?',(case['project_id'],actor)).fetchone() or db.execute('SELECT 1 FROM reviewer_assignments WHERE project_id=? AND user_id=?',(case['project_id'],actor)).fetchone()):
            fail(403,'CASE_ACCESS_DENIED','Not authorized to view this case')
        rows=db.execute('''SELECT a.id,a.attempt_no,a.state,a.submitted_by,d.decision,d.comment
          FROM submission_attempts a LEFT JOIN approval_decisions d ON d.attempt_id=a.id
          WHERE a.case_id=? ORDER BY a.attempt_no''',(case_id,)).fetchall()
        return {'caseId':case_id,'state':case['state'],'caseVersion':case['row_version'],'attempts':[dict(r) for r in rows]}
    finally: db.close()

@app.get('/health')
def health(): return {'status':'demo-only'}

if __name__=='__main__':
    init_demo()
    import uvicorn
    uvicorn.run(app, host='127.0.0.1',port=8765)
